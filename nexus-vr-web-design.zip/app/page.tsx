'use client'

import { useEffect, useRef, useState } from 'react'
import { ArrowUpRight, ChevronDown, Menu, ShoppingBag, X } from 'lucide-react'

const products = [
  { name: 'NEXUS Vision Pro', type: 'Spatial computer', price: '$3,499', image: '/nexus-vision-pro.png', tag: 'New' },
  { name: 'NEXUS Motion', type: 'Precision controllers', price: '$299', image: '/nexus-controllers.png', tag: '' },
  { name: 'Aero Strap', type: 'Performance head strap', price: '$189', image: '/nexus-accessories.png', tag: 'Essential' },
  { name: 'Travel Case', type: 'Protective carry system', price: '$249', image: '/nexus-accessories.png', tag: '' },
]

function Magnetic({ children, className = '', ...props }: React.HTMLAttributes<HTMLAnchorElement> & { children: React.ReactNode }) {
  const ref = useRef<HTMLAnchorElement>(null)
  const move = (event: React.PointerEvent<HTMLAnchorElement>) => {
    const rect = ref.current?.getBoundingClientRect()
    if (!rect) return
    const x = (event.clientX - rect.left - rect.width / 2) * 0.16
    const y = (event.clientY - rect.top - rect.height / 2) * 0.16
    ref.current.style.transform = `translate(${x}px, ${y}px)`
  }
  return <a ref={ref} className={className} onPointerMove={move} onPointerLeave={() => { if (ref.current) ref.current.style.transform = '' }} {...props}>{children}</a>
}

function TiltCard({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  const ref = useRef<HTMLDivElement>(null)
  return <div ref={ref} className={className} onPointerMove={(event) => { const rect = ref.current?.getBoundingClientRect(); if (!rect || !ref.current) return; const x = (event.clientX - rect.left) / rect.width - .5; const y = (event.clientY - rect.top) / rect.height - .5; ref.current.style.setProperty('--tilt-x', `${y * -5}deg`); ref.current.style.setProperty('--tilt-y', `${x * 5}deg`); ref.current.style.setProperty('--glow-x', `${event.clientX - rect.left}px`); ref.current.style.setProperty('--glow-y', `${event.clientY - rect.top}px`) }} onPointerLeave={() => { if (ref.current) { ref.current.style.setProperty('--tilt-x', '0deg'); ref.current.style.setProperty('--tilt-y', '0deg') } }}>{children}</div>
}

export default function Page() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [bagCount, setBagCount] = useState(0)
  const heroRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const onScroll = () => { if (heroRef.current) heroRef.current.style.setProperty('--scroll-progress', String(Math.min(1, Math.max(0, window.scrollY / 560)))) }
    window.addEventListener('scroll', onScroll, { passive: true }); onScroll()
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return <main className="site-shell">
    <header className="topbar"><a className="wordmark" href="#top" aria-label="NEXUS VR home">NEXUS<span>VR</span></a><nav className={`nav-links ${menuOpen ? 'is-open' : ''}`} aria-label="Main navigation"><a href="#collections" onClick={() => setMenuOpen(false)}>Collections</a><a href="#catalog" onClick={() => setMenuOpen(false)}>Shop</a><a href="#experience" onClick={() => setMenuOpen(false)}>Experience</a><a href="#footer" onClick={() => setMenuOpen(false)}>Journal</a></nav><div className="top-actions"><button className="bag-button" aria-label={`Shopping bag, ${bagCount} items`} onClick={() => setBagCount((count) => count + 1)}><ShoppingBag size={18} strokeWidth={1.5} /> <span>{bagCount.toString().padStart(2, '0')}</span></button><button className="menu-button" aria-label={menuOpen ? 'Close menu' : 'Open menu'} onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X size={20} /> : <Menu size={20} />}</button></div></header>

    <section className="hero" id="top" ref={heroRef}><div className="hero-copy"><p className="eyebrow">NEXUS / 01</p><h1>See beyond<br /><em>the visible.</em></h1><p className="hero-description">A new dimension of computing, designed around the way you see, move, and live.</p><Magnetic className="pill-button dark" href="#catalog">Explore products <ArrowUpRight size={16} /></Magnetic></div><div className="hero-visual"><div className="orbit orbit-one" /><div className="orbit orbit-two" /><div className="exploded-layer layer-band" /><div className="exploded-layer layer-glass" /><img src="/nexus-vision-pro.png" alt="NEXUS Vision Pro headset" /><p className="hero-caption">NEXUS VISION PRO<br /><span>Spatial computing, redefined.</span></p></div><div className="scroll-note">Scroll to explore <ChevronDown size={14} /></div></section>

    <section className="cinematic" id="experience"><div className="cinematic-sticky"><p className="eyebrow">A new way forward</p><div className="story-line">Sức mạnh <em>không tưởng.</em></div><div className="story-line">Gói gọn trong <em>tầm nhìn.</em></div><div className="story-line">Made for what&apos;s <em>next.</em></div></div></section>

    <section className="features section-pad"><div className="section-intro"><p className="eyebrow">The NEXUS difference</p><h2>Technology that<br /><em>disappears.</em></h2></div><div className="feature-grid"><article><span className="feature-number">01</span><h3>Infinite canvas</h3><p>Expand your workspace beyond the limits of any physical display.</p><strong>23 million pixels</strong></article><article><span className="feature-number">02</span><h3>Natural interaction</h3><p>Navigate with your eyes, hands, and voice. No controller required.</p><strong>EyeSight + hand tracking</strong></article><article><span className="feature-number">03</span><h3>All-day comfort</h3><p>Precision balanced materials made for hours of effortless immersion.</p><strong>450 g aerospace alloy</strong></article></div></section>

    <section className="collections section-pad" id="collections"><div className="section-heading"><div><p className="eyebrow">Curated for you</p><h2>Enter your<br /><em>next world.</em></h2></div><Magnetic className="text-link" href="#catalog">View all collections <ArrowUpRight size={15} /></Magnetic></div><div className="collection-grid"><a href="#catalog" className="collection-card collection-large"><img src="/nexus-vision-pro.png" alt="NEXUS Vision Pro headset collection" /><div className="collection-overlay"><p>01 / Headsets</p><h3>NEXUS Vision Pro</h3><span>Explore the collection <ArrowUpRight size={16} /></span></div></a><a href="#catalog" className="collection-card collection-small"><img src="/nexus-accessories.png" alt="NEXUS premium leather accessories" /><div className="collection-overlay"><p>02 / Accessories</p><h3>Made to move</h3><span>Discover essentials <ArrowUpRight size={16} /></span></div></a></div></section>

    <section className="accessories section-pad"><div className="section-heading"><div><p className="eyebrow">The ecosystem</p><h2>Everything<br /><em>in place.</em></h2></div></div><div className="bento-grid"><TiltCard className="bento-card bento-wide"><img src="/nexus-controllers.png" alt="NEXUS Motion controllers" /><div><p>01 / NEXUS Motion</p><h3>Precision, in your hands.</h3></div></TiltCard><TiltCard className="bento-card bento-tall"><img src="/nexus-accessories.png" alt="NEXUS Aero Strap" /><div><p>02 / Aero Strap</p><h3>Comfort refined.</h3></div></TiltCard><TiltCard className="bento-card bento-dark"><div><p>03 / The NEXUS system</p><h3>Designed as<br /><em>one.</em></h3></div><ArrowUpRight /></TiltCard></div></section>

    <section className="catalog section-pad" id="catalog"><div className="section-heading"><div><p className="eyebrow">The collection</p><h2>Objects of<br /><em>wonder.</em></h2></div><button className="filter-button">All products <ChevronDown size={15} /></button></div><div className="product-grid">{products.map((product) => <article className="product-card" key={product.name}><div className="product-image"><img src={product.image} alt={product.name} /><button aria-label={`Add ${product.name} to bag`} onClick={() => setBagCount((count) => count + 1)}><span>+</span></button></div><div className="product-meta"><div><p>{product.type}</p><h3>{product.name}</h3></div><strong>{product.price}</strong></div>{product.tag && <span className="product-tag">{product.tag}</span>}</article>)}</div></section>

    <footer className="footer section-pad" id="footer"><div className="footer-top"><div><a className="wordmark" href="#top">NEXUS<span>VR</span></a><p className="footer-statement">The future is closer<br />than you think.</p></div><div className="newsletter"><p className="eyebrow">Stay in the know</p><div className="email-line"><input type="email" placeholder="Your email address" aria-label="Your email address" /><button aria-label="Subscribe"><ArrowUpRight size={18} /></button></div></div></div><div className="footer-bottom"><span>© 2025 NEXUS VR</span><div><a href="#top">Instagram</a><a href="#top">YouTube</a><a href="#top">Contact</a></div><a href="#top">Back to top ↑</a></div></footer>
  </main>
}
